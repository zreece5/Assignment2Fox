import PackageDescription

let package = Package(
    name: "GildedRose"
)
