package com.gildedrose

data class Item(var name: String, var sellIn: Int, var quality: Int)