defmodule GildedRoseTest do
  use ExUnit.Case

  test "begin the journey of refactoring" do
  end
end
